from time import sleep
import asyncio
from azure_logger import log
from state import NLWebHandlerState


class PostPrepare:
    """This class is used to check if the pre processing for the query before any results are returned."""
    
    def __init__(self, handler):
        self.handler = handler

    def report_state(self):
        log(f"Waiting for pre-checks to complete in post_prepare:")
        log(f"  analyze_query: {self.handler.state.analyze_query}")
        log(f"  query_relevance: {self.handler.state.query_relevance}")
        log(f"  required_info: {self.handler.state.required_info}")
        log(f"  decontextualization: {self.handler.state.decontextualization}")
        log(f"  memory_items: {self.handler.state.memory_items}")

    async def do(self):
        if (self.handler.is_connection_alive == False):
            log(f"Connection is dead, setting query_done to True")
            self.handler.query_done = True
            return
       
        while (self.handler.state.analyze_query != NLWebHandlerState.DONE or
               self.handler.state.query_relevance != NLWebHandlerState.DONE or
               self.handler.state.required_info != NLWebHandlerState.DONE or
               self.handler.state.decontextualization != NLWebHandlerState.DONE or
               self.handler.state.memory_items != NLWebHandlerState.DONE):
            # self.report_state()
            if (self.handler.query_done):
                log(f"Query done, setting pre_checks_done to True")
                return
            await asyncio.sleep(.05)
        self.handler.pre_checks_done = True
        
        
        
      
       
        
