import os
from dotenv import load_dotenv

def load_environment():
    """
    Load environment variables from .env file if it exists
    Otherwise, assume they are set in the deployment environment
    """
    # Try to load from .env file
    load_dotenv()
    
    # Check for required environment variables
    required_vars = [
        'AZURE_SEARCH_API_KEY',
        'AZURE_EMBEDDING_API_KEY',
        'AZURE_OPENAI_API_KEY',
        'AZURE_DEEPSEEK_KEY',
        'OPENAI_API_KEY',
        'ANTHROPIC_API_KEY'
    ]
    
    # Log which variables are set (without revealing their values)
    for var in required_vars:
        if os.environ.get(var):
            print(f"Environment variable {var} is set")
        else:
            print(f"WARNING: Environment variable {var} is not set")

if __name__ == "__main__":
    load_environment()
