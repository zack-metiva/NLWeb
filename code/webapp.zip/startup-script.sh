#!/bin/bash

# Create static directory if it doesn't exist
mkdir -p static/html

# Copy HTML, CSS, and JavaScript files to static directory
cp -r *.html static/
cp -r *.css static/
cp -r *.js static/
cp -r html/* static/html/

# Start the application using Gunicorn
gunicorn app:app --config=gunicorn.conf.py
