# Gunicorn configuration file for Azure Web App
import multiprocessing
import os

# The number of worker processes for handling requests
workers = int(os.environ.get('WEB_CONCURRENCY', multiprocessing.cpu_count() * 2 + 1))

# The socket to bind
bind = '0.0.0.0:' + os.environ.get('PORT', '8000')

# Restart workers after this many requests
max_requests = 1000
max_requests_jitter = 50

# Set timeout to 120 seconds
timeout = 120

# Use async worker
worker_class = 'aiohttp.GunicornWebWorker'

# Logging
accesslog = '-'
errorlog = '-'
loglevel = 'info'
