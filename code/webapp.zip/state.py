# This file contains the state of the NLWebHandler.
# It is used to track the state of the handler and the various stages
# of the query.

class NLWebHandlerState:

    INITIAL = 0
    DONE = 2

    def __init__(self, handler):
        self.handler = handler
        self.decontextualization = self.__class__.INITIAL
        self.initial_retrieval = self.__class__.INITIAL
        self.query_relevance = self.__class__.INITIAL
        self.secondary_retrieval = self.__class__.INITIAL
        self.required_info = self.__class__.INITIAL
        self.memory_items = self.__class__.INITIAL
        self.ranking = self.__class__.INITIAL
        self.analyze_query = self.__class__.INITIAL

    def set_decontextualization_done(self):
        self.decontextualization = self.__class__.DONE
        self.handler.check_pre_checks_done()

    def set_analyze_query_done(self):
        self.analyze_query = self.__class__.DONE
        self.handler.check_pre_checks_done()    

    def set_query_relevance_done(self):
        self.query_relevance = self.__class__.DONE
        self.handler.check_pre_checks_done()

    def set_required_info_done(self):
        self.required_info = self.__class__.DONE
        self.handler.check_pre_checks_done()

    def set_memory_items_done(self):
        self.memory_items = self.__class__.DONE
        self.handler.check_pre_checks_done()