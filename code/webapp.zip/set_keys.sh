
export AZURE_VECTOR_SEARCH_ENDPOINT="https://nlweb-vector-search.search.windows.net"
export AZURE_VECTOR_SEARCH_API_KEY="MVg7SU4R9b3CRIcAabgab0t162ZGcoV5shYs0KXav9AzSeCUSlkg"

export AZURE_OPENAI_ENDPOINT="https://nlweboaiinstance1.openai.azure.com/"
export AZURE_OPENAI_API_KEY="KvY0ACKw3p5jfvjgDU9yTLYwA9kBILPuIudgXbmb3w1sw71sz1CGJQQJ99BDACHYHv6XJ3w3AAABACOG3Apv"

