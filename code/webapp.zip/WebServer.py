import asyncio
import json
import urllib.parse
import os
import sys
import time
import logging
import traceback
from baseHandler import NLWebHandler
from StreamingWrapper import HandleRequest
from generate_answer import GenerateAnswer
from utils import get_param
from azure_logger import log, close_logs  # Import our new logging utility

# Set up logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('WebServer')

# Simple asyncio based web server. Needs to be replaced before any real deployment.

# Determine the application root directory based on environment
def get_app_root():
    """Get the application root directory, handling both local and Azure environments."""
    # Check if running in Azure App Service
    if 'WEBSITE_SITE_NAME' in os.environ:
        # Azure App Service - use D:\home\site\wwwroot or the HOME environment variable
        azure_home = os.environ.get('HOME', '/home/site/wwwroot')
        logger.info(f"Using Azure App Service root directory: {azure_home}")
        log(f"Using Azure App Service root directory: {azure_home}")
        return azure_home
    else:
        # Local development - use the directory of this script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        logger.info(f"Using local development root directory: {script_dir}")
        return script_dir

# Get the app root directory
APP_ROOT = get_app_root()
logger.info(f"Application root directory: {APP_ROOT}")
log(f"Application root directory: {APP_ROOT}")

# List all files in the app root and subdirectories to verify structure
def log_directory_structure(start_path=APP_ROOT, max_depth=3, current_depth=0):
    """Log the directory structure for debugging purposes."""
    if current_depth > max_depth:
        return
        
    try:
        for item in os.listdir(start_path):
            item_path = os.path.join(start_path, item)
            rel_path = os.path.relpath(item_path, APP_ROOT)
            if os.path.isdir(item_path):
                logger.debug(f"DIR: {rel_path}")
                log(f"DIR: {rel_path}")
                log_directory_structure(item_path, max_depth, current_depth + 1)
            else:
                logger.debug(f"FILE: {rel_path}")
                log(f"FILE: {rel_path}")
    except Exception as e:
        logger.error(f"Error listing directory {start_path}: {str(e)}")
        log(f"Error listing directory {start_path}: {str(e)}")

# Log the directory structure on startup
logger.info("Logging directory structure:")
log("Logging directory structure:")
log_directory_structure()

async def handle_client(reader, writer, fulfill_request):
    """Handle a client connection by parsing the HTTP request and passing it to fulfill_request."""
    request_id = f"client_{int(time.time()*1000)}"
    connection_alive = True
    
    try:
        # Read the request line
        request_line = await reader.readline()
        if not request_line:
            logger.warning(f"[{request_id}] Empty request line, closing connection")
            log(f"[{request_id}] Empty request line, closing connection")
            connection_alive = False
            return
            
        request_line = request_line.decode('utf-8', errors='replace').rstrip('\r\n')
        words = request_line.split()
        if len(words) < 2:
            # Bad request
            writer.write(b"HTTP/1.1 400 Bad Request\r\n\r\n")
            await writer.drain()
            connection_alive = False
            return
            
        method, path = words[0], words[1]
        logger.info(f"[{request_id}] Received {method} request for {path}")
        log(f"[{request_id}] Received {method} request for {path}")
        
        # Parse headers
        headers = {}
        while True:
            try:
                header_line = await reader.readline()
                if not header_line or header_line == b'\r\n':
                    break
                    
                hdr = header_line.decode('utf-8').rstrip('\r\n')
                if ":" not in hdr:
                    continue
                name, value = hdr.split(":", 1)
                headers[name.strip().lower()] = value.strip()
            except (ConnectionResetError, BrokenPipeError) as e:
                logger.error(f"[{request_id}] Connection lost while reading headers: {str(e)}")
                log(f"[{request_id}] Connection lost while reading headers: {str(e)}")
                connection_alive = False
                return
        
        # Parse query parameters
        if '?' in path:
            path, query_string = path.split('?', 1)
            query_params = {}
            try:
                # Parse query parameters into a dictionary of lists
                for key, values in urllib.parse.parse_qs(query_string).items():
                    query_params[key] = values
            except Exception as e:
                logger.error(f"[{request_id}] Error parsing query parameters: {str(e)}")
                log(f"[{request_id}] Error parsing query parameters: {str(e)}")
                query_params = {}
        else:
            query_params = {}
        
        # Read request body if Content-Length is provided
        body = None
        if 'content-length' in headers:
            try:
                content_length = int(headers['content-length'])
                body = await reader.read(content_length)
            except (ValueError, ConnectionResetError, BrokenPipeError) as e:
                logger.error(f"[{request_id}] Error reading request body: {str(e)}")
                log(f"[{request_id}] Error reading request body: {str(e)}")
                connection_alive = False
                return
        
        # Create a streaming response handler
        async def send_response(status_code, response_headers, end_response=False):
            """Send HTTP status and headers to the client."""
            nonlocal connection_alive
            
            if not connection_alive:
                return
                
            try:
                status_line = f"HTTP/1.1 {status_code}\r\n"
                writer.write(status_line.encode('utf-8'))
                
                # Send headers
                for header_name, header_value in response_headers.items():
                    header_line = f"{header_name}: {header_value}\r\n"
                    writer.write(header_line.encode('utf-8'))
                
                # End headers
                writer.write(b"\r\n")
                await writer.drain()
                
                logger.debug(f"[{request_id}] Sent response headers: {status_code}, {response_headers}")
                log(f"[{request_id}] Sent response headers: {status_code}, {response_headers}")
                
                # Signal that we've sent the headers
                send_response.headers_sent = True
                send_response.ended = end_response
            except (ConnectionResetError, BrokenPipeError) as e:
                logger.error(f"[{request_id}] Connection lost while sending response headers: {str(e)}")
                log(f"[{request_id}] Connection lost while sending response headers: {str(e)}")
                connection_alive = False
            except Exception as e:
                logger.error(f"[{request_id}] Error sending response headers: {str(e)}")
                log(f"[{request_id}] Error sending response headers: {str(e)}")
                connection_alive = False
        
        # Create a streaming content sender
        async def send_chunk(chunk, end_response=False):
            """Send a chunk of data to the client."""
            nonlocal connection_alive
            
            if not connection_alive:
                return
                
            if not hasattr(send_response, 'headers_sent') or not send_response.headers_sent:
                logger.error(f"[{request_id}] Headers must be sent before content")
                log(f"[{request_id}] Headers must be sent before content")
                return
                
            if hasattr(send_response, 'ended') and send_response.ended:
                logger.error(f"[{request_id}] Response has already been ended")
                log(f"[{request_id}] Response has already been ended")
                return
                
            try:
                chunk_size = 0
                if chunk:
                    if isinstance(chunk, str):
                        data = chunk.encode('utf-8')
                        chunk_size = len(data)
                        writer.write(data)
                    else:
                        chunk_size = len(chunk)
                        writer.write(chunk)
                    await writer.drain()
                
           #     logger.debug(f"[{request_id}] Sent chunk of size {chunk_size}, end_response={end_response}")
           #     log(f"[{request_id}] Sent chunk of size {chunk_size}, end_response={end_response}")
                send_response.ended = end_response
            except (ConnectionResetError, BrokenPipeError) as e:
                logger.error(f"[{request_id}] Connection lost while sending chunk: {str(e)}")
                log(f"[{request_id}] Connection lost while sending chunk: {str(e)}")
                connection_alive = False
            except Exception as e:
                logger.error(f"[{request_id}] Error sending chunk: {str(e)}")
                log(f"[{request_id}] Error sending chunk: {str(e)}")
                connection_alive = False
        
        # Call the user-provided fulfill_request function with streaming capabilities
        if connection_alive:
            try:
              
                await fulfill_request(
                    method=method,
                    path=urllib.parse.unquote(path),
                    headers=headers,
                    query_params=query_params,
                    body=body,
                    send_response=send_response,
                    send_chunk=send_chunk
                )
            except Exception as e:
                logger.error(f"[{request_id}] Error in fulfill_request: {str(e)}")
                logger.error(f"[{request_id}] Error traceback:", exc_info=True)
                log(f"[{request_id}] Error in fulfill_request: {str(e)}")
                log(f"[{request_id}] Error traceback: {traceback.format_exc()}")
                if connection_alive and not (hasattr(send_response, 'headers_sent') and send_response.headers_sent):
                    try:
                        # Send a 500 error if headers haven't been sent yet
                        error_headers = {
                            'Content-Type': 'text/plain',
                            'Connection': 'close'
                        }
                        await send_response(500, error_headers)
                        await send_chunk(f"Internal server error: {str(e)}".encode('utf-8'), end_response=True)
                    except:
                        pass
        
    except Exception as e:
        logger.error(f"[{request_id}] Critical error handling request: {str(e)}")
        logger.error(f"[{request_id}] Error traceback:", exc_info=True)
        log(f"[{request_id}] Critical error handling request: {str(e)}")
        log(f"[{request_id}] Error traceback: {traceback.format_exc()}")
    finally:
        # Close the connection in a controlled manner
        try:
            await writer.drain()
            writer.close()
            await writer.wait_closed()
            logger.info(f"[{request_id}] Connection closed")
            log(f"[{request_id}] Connection closed")
        except Exception as e:
            logger.error(f"[{request_id}] Error closing connection: {str(e)}")
            log(f"[{request_id}] Error closing connection: {str(e)}")
            
async def start_server(host='0.0.0.0', port=8000, fulfill_request=None, use_https=False, 
                 ssl_cert_file=None, ssl_key_file=None):
    """
    Start the HTTP/HTTPS server with the provided request handler.
    """
    import ssl
    
    if fulfill_request is None:
        raise ValueError("fulfill_request function must be provided")
    
    ssl_context = None
    if use_https:
        if not ssl_cert_file or not ssl_key_file:
            raise ValueError("SSL certificate and key files must be provided for HTTPS")
        
        # Create SSL context - using configuration from working code
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_context.minimum_version = ssl.TLSVersion.TLSv1_2
        ssl_context.maximum_version = ssl.TLSVersion.TLSv1_3
        ssl_context.set_ciphers('ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256')
        ssl_context.options |= ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
        
        try:
            ssl_context.load_cert_chain(ssl_cert_file, ssl_key_file)
        except (ssl.SSLError, FileNotFoundError) as e:
            raise ValueError(f"Failed to load SSL certificate: {e}")
    
    # Start server with or without SSL
    server = await asyncio.start_server(
        lambda r, w: handle_client(r, w, fulfill_request), 
        host, 
        port,
        ssl=ssl_context
    )
    
    addr = server.sockets[0].getsockname()
    protocol = "HTTPS" if use_https else "HTTP"
    url_protocol = "https" if use_https else "http"
    logger.info(f'Serving {protocol} on {addr[0]} port {addr[1]} ({url_protocol}://{addr[0]}:{addr[1]}/) ...')
    log(f'Serving {protocol} on {addr[0]} port {addr[1]} ({url_protocol}://{addr[0]}:{addr[1]}/) ...')
    async with server:
        await server.serve_forever()


class SendChunkWrapper:
    def __init__(self, send_chunk):
        self.send_chunk = send_chunk
        self.closed = False

    async def write(self, chunk, end_response=False):
        if self.closed:
            return
     #   logger.info(f"Writing chunk: {chunk}")
     #   log(f"Writing chunk: {chunk}")
        try:
            if isinstance(chunk, dict):
                message = f"data: {json.dumps(chunk)}\n\n"
                await self.send_chunk(message, end_response)
            else:
                await self.send_chunk(chunk, end_response)
                
            if end_response:
                self.closed = True
        except (ConnectionResetError, BrokenPipeError) as e:
            logger.error(f"Connection lost in write: {str(e)}")
            log(f"Connection lost in write: {str(e)}")
            self.closed = True
        except Exception as e:
            logger.error(f"Error in SendChunkWrapper.write: {str(e)}")
            log(f"Error in SendChunkWrapper.write: {str(e)}")
            self.closed = True

    async def write_stream(self, message, end_response=False):
        if self.closed:
            return
            
        try:
            data_message = f"data: {json.dumps(message)}\n\n"
            await self.send_chunk(data_message, end_response)
            if end_response:
                self.closed = True
        except (ConnectionResetError, BrokenPipeError) as e:
            logger.error(f"Connection lost in write_stream: {str(e)}")
            log(f"Connection lost in write_stream: {str(e)}")
            self.closed = True
        except Exception as e:
            logger.error(f"Error in write_stream: {str(e)}")
            log(f"Error in write_stream: {str(e)}")
            self.closed = True

async def handle_mcp_request(query_params, body, send_response, send_chunk):
    """
    Handle an MCP request by processing it with NLWebHandler
    
    Args:
        query_params (dict): URL query parameters
        body (bytes): Request body
        send_response (callable): Function to send response headers
        send_chunk (callable): Function to send response body
    """
    logger.info("Handling MCP request")
    log("Handling MCP request")
    
    try:
        # Parse the request body as JSON
        if body:
            try:
                request_data = json.loads(body)
                logger.info(f"MCP request data: {request_data}")
                log(f"MCP request data: {request_data}")
                
                # Extract the function call details
                function_call = request_data.get("function_call", {})
                function_name = function_call.get("name")
                
                if function_name != "ask":
                    # Return error for unsupported functions
                    error_response = {
                        "type": "function_response",
                        "status": "error",
                        "error": f"Unknown function: {function_name}"
                    }
                    await send_response(400, {'Content-Type': 'application/json'})
                    await send_chunk(json.dumps(error_response), end_response=True)
                    return
                
                # Parse function arguments
                arguments = json.loads(function_call.get("arguments", "{}"))
                
                # Extract the query parameter (required)
                query = arguments.get("query")
                
                if not query:
                    # Return error for missing query parameter
                    error_response = {
                        "type": "function_response",
                        "status": "error",
                        "error": "Missing required parameter: query"
                    }
                    await send_response(400, {'Content-Type': 'application/json'})
                    await send_chunk(json.dumps(error_response), end_response=True)
                    return
                
                # Initialize query_params if it doesn't exist
                if query_params is None:
                    query_params = {}
                
                # Add the query to query_params for NLWebHandler
                query_params["query"] = [query]
                
                # Add optional parameters if they exist in the arguments
                if "site" in arguments:
                    query_params["site"] = [arguments["site"]]
                
                if "prev_query" in arguments:
                    query_params["prev_query"] = [arguments["prev_query"]]
                
                if "context_url" in arguments:
                    query_params["context_url"] = [arguments["context_url"]]
                
                # Call NLWebHandler to process the request
                result = await NLWebHandler(query_params, None).runQuery()
                
                # Format the response according to MCP protocol
                mcp_response = {
                    "type": "function_response",
                    "status": "success",
                    "response": result.get("answer", "")
                }
                
                # Send the response
                await send_response(200, {'Content-Type': 'application/json'})
                await send_chunk(json.dumps(mcp_response), end_response=True)
                
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in MCP request: {e}")
                log(f"Invalid JSON in MCP request: {e}")
                await send_response(400, {'Content-Type': 'application/json'})
                await send_chunk(json.dumps({
                    "type": "function_response",
                    "status": "error",
                    "error": f"Invalid JSON: {str(e)}"
                }), end_response=True)
        else:
            logger.error("Empty MCP request body")
            log("Empty MCP request body")
            await send_response(400, {'Content-Type': 'application/json'})
            await send_chunk(json.dumps({
                "type": "function_response",
                "status": "error",
                "error": "Empty request body"
            }), end_response=True)
            
    except Exception as e:
        logger.error(f"Error processing MCP request: {e}", exc_info=True)
        log(f"Error processing MCP request: {e}\n{traceback.format_exc()}")
        await send_response(500, {'Content-Type': 'application/json'})
        await send_chunk(json.dumps({
            "type": "function_response",
            "status": "error",
            "error": f"Internal server error: {str(e)}"
        }), end_response=True)
async def handle_mcp_request(query_params, body, send_response, send_chunk):
    """
    Handle an MCP request by processing it with NLWebHandler
    
    Args:
        query_params (dict): URL query parameters
        body (bytes): Request body
        send_response (callable): Function to send response headers
        send_chunk (callable): Function to send response body
    """
    logger.info("Handling MCP request")
    log("Handling MCP request")
    
    try:
        # Parse the request body as JSON
        if body:
            try:
                request_data = json.loads(body)
                logger.info(f"MCP request data: {request_data}")
                log(f"MCP request data: {request_data}")
                
                # Extract the function call details
                function_call = request_data.get("function_call", {})
                function_name = function_call.get("name")
                
                if function_name != "ask":
                    # Return error for unsupported functions
                    error_response = {
                        "type": "function_response",
                        "status": "error",
                        "error": f"Unknown function: {function_name}"
                    }
                    await send_response(400, {'Content-Type': 'application/json'})
                    await send_chunk(json.dumps(error_response), end_response=True)
                    return
                
                # Parse function arguments
                arguments = json.loads(function_call.get("arguments", "{}"))
                question = arguments.get("question")
                
                if not question:
                    # Return error for missing question parameter
                    error_response = {
                        "type": "function_response",
                        "status": "error",
                        "error": "Missing required parameter: question"
                    }
                    await send_response(400, {'Content-Type': 'application/json'})
                    await send_chunk(json.dumps(error_response), end_response=True)
                    return
                
                # Add the question to query_params for NLWebHandler
                if query_params is None:
                    query_params = {}
                query_params["query"] = [question]
                
                # Call NLWebHandler to process the request
                result = await NLWebHandler(query_params, None).runQuery()
                
                # Format the response according to MCP protocol
                mcp_response = {
                    "type": "function_response",
                    "status": "success",
                    "response": result.get("answer", "")
                }
                
                # Send the response
                await send_response(200, {'Content-Type': 'application/json'})
                await send_chunk(json.dumps(mcp_response), end_response=True)
                
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in MCP request: {e}")
                log(f"Invalid JSON in MCP request: {e}")
                await send_response(400, {'Content-Type': 'application/json'})
                await send_chunk(json.dumps({
                    "type": "function_response",
                    "status": "error",
                    "error": f"Invalid JSON: {str(e)}"
                }), end_response=True)
        else:
            logger.error("Empty MCP request body")
            log("Empty MCP request body")
            await send_response(400, {'Content-Type': 'application/json'})
            await send_chunk(json.dumps({
                "type": "function_response",
                "status": "error",
                "error": "Empty request body"
            }), end_response=True)
            
    except Exception as e:
        logger.error(f"Error processing MCP request: {e}", exc_info=True)
        log(f"Error processing MCP request: {e}\n{traceback.format_exc()}")
        await send_response(500, {'Content-Type': 'application/json'})
        await send_chunk(json.dumps({
            "type": "function_response",
            "status": "error",
            "error": f"Internal server error: {str(e)}"
        }), end_response=True)


async def fulfill_request(method, path, headers, query_params, body, send_response, send_chunk):
    '''
    Process an HTTP request and stream the response back.
    
    Args:
        method (str): HTTP method (GET, POST, etc.)
        path (str): URL path
        headers (dict): HTTP headers
        query_params (dict): URL query parameters
        body (bytes or None): Request body
        send_response (callable): Function to send response headers
        send_chunk (callable): Function to send response body chunks
    '''
    try:
        streaming = True
        generate_mode = "none"
        if ("streaming" in query_params):
            strval = get_param(query_params, "streaming", str, "True")
            streaming = strval not in ["False", "false", "0"]

        if ("generate_mode" in query_params):
            generate_mode = get_param(query_params, "generate_mode", str, "none")
           
        if (path.find("html/") != -1) or path.find("static/") != -1 or (path.find("png") != -1):
            await send_static_file(path, send_response, send_chunk)
            return
        elif (path.find("who") != -1):
            retval =  await whoHandler(query_params, None).runQuery()
            await send_response(200, {'Content-Type': 'application/json'})
            await send_chunk(json.dumps(retval), end_response=True)
            return
        elif (path.find("mcp") != -1):
            # Handle MCP requests
            logger.info("Routing to MCP handler")
            log("Routing to MCP handler")
            await handle_mcp_request(query_params, body, send_response, send_chunk)
            return
        elif (path.find("ask") != -1):
            if (not streaming):
                if (generate_mode == "generate"):
                    retval = await GenerateAnswer(query_params, None).runQuery()
                else:
                    retval = await NLWebHandler(query_params, None).runQuery()
                await send_response(200, {'Content-Type': 'application/json'})
                await send_chunk(json.dumps(retval), end_response=True)
                return
            else:   
                # Set proper headers for server-sent events (SSE)
                response_headers = {
                    'Content-Type': 'text/event-stream',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'X-Accel-Buffering': 'no'  # Disable proxy buffering
                }
                
                # Send SSE headers
                await send_response(200, response_headers)
                
                # Send initial keep-alive comment to establish connection
                await send_chunk(": keep-alive\n\n", end_response=False)
                
                # Create wrapper for chunk sending
                send_chunk_wrapper = SendChunkWrapper(send_chunk)
                
                # Handle the request
                hr = HandleRequest(method, path, headers, query_params, 
                                   body, send_response, send_chunk_wrapper, generate_mode)
                await hr.do_GET()
        else:
            # Default handler for unknown paths
            logger.warning(f"No handler found for path: {path}")
            log(f"No handler found for path: {path}")
            await send_response(404, {'Content-Type': 'text/plain'})
            await send_chunk(f"No handler found for path: {path}".encode('utf-8'), end_response=True)
    except Exception as e:
        logger.error(f"Error in fulfill_request: {e}", exc_info=True)
        log(f"Error in fulfill_request: {e}\n{traceback.format_exc()}")
        raise

async def send_static_file(path, send_response, send_chunk):
    # Map file extensions to MIME types
    mime_types = {
        '.html': 'text/html',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.css': 'text/css',
        '.js': 'application/javascript'
    }

    # Get file extension and corresponding MIME type
    file_ext = os.path.splitext(path)[1].lower()
    content_type = mime_types.get(file_ext, 'application/octet-stream')
    
    logger.info(f"Handling static file: {path} (content type: {content_type})")
    log(f"Handling static file: {path} (content type: {content_type})")

    try:
        # Remove leading slash and sanitize path
        safe_path = os.path.normpath(path.lstrip('/'))

        # Try multiple possible root locations
        possible_roots = [
            APP_ROOT,
            os.path.join(APP_ROOT, 'site', 'wwwroot'),
            '/home/site/wwwroot',
            os.environ.get('HOME', ''),
        ]
        
        # Remove empty paths
        possible_roots = [root for root in possible_roots if root]
        
        file_found = False
        full_path = None
       
        for root in possible_roots:
            try_path = os.path.join(root, safe_path)
            if os.path.isfile(try_path):
                full_path = try_path
                file_found = True
                break
        
        if not file_found:
            # Special case: check if removing 'html/' prefix works
            if safe_path.startswith('html/'):
                stripped_path = safe_path[5:]  # Remove 'html/' prefix
                for root in possible_roots:
                    try_path = os.path.join(root, stripped_path)
                    
                    if os.path.isfile(try_path):
                        full_path = try_path
                        file_found = True
                        break
        
        if not file_found:
            # Special case: check if there's no html/static directory
            # and the files are directly in the root
            parts = safe_path.split('/')
            if len(parts) > 1:
                filename = parts[-1]
                for root in possible_roots:
                    try_path = os.path.join(root, filename)
                    if os.path.isfile(try_path):
                        full_path = try_path
                        file_found = True
                        break
        
        if file_found:
            # Try to open and read the file
            with open(full_path, 'rb') as f:
                content = f.read()
                
            # Send successful response with proper headers
            await send_response(200, {'Content-Type': content_type, 'Content-Length': str(len(content))})
            await send_chunk(content, end_response=True)
            return
        
        # If we reached here, the file was not found
        error_msg = f"File not found (1): {path} {full_path}{possible_roots}{safe_path}"
        logger.error(error_msg)
        logger.error(f"Tried paths: {possible_roots}")
        log(error_msg)
        log(f"Tried paths: {possible_roots}")
        await send_response(404, {'Content-Type': 'text/plain'})
        await send_chunk(error_msg.encode('utf-8'), end_response=True)
        
    except FileNotFoundError:
        # Send 404 if file not found
        error_msg = f"File not found (2): {path}"
        logger.error(error_msg)
        log(error_msg)
        await send_response(404, {'Content-Type': 'text/plain'})
        await send_chunk(error_msg.encode('utf-8'), end_response=True)
        
    except Exception as e:
        # Send 500 for other errors
        error_msg = f"Internal server error: {str(e)}"
        logger.error(error_msg, exc_info=True)
        log(f"{error_msg}\n{traceback.format_exc()}")
        await send_response(500, {'Content-Type': 'text/plain'})
        await send_chunk(error_msg.encode('utf-8'), end_response=True)

# Azure Web App specific: Check for the PORT environment variable
def get_port():
    """Get the port to listen on, defaulting to 8000 if not specified."""
    if 'PORT' in os.environ:
        port = int(os.environ['PORT'])
        logger.info(f"Using PORT from environment variable: {port}")
        log(f"Using PORT from environment variable: {port}")
        return port
    elif 'WEBSITE_SITE_NAME' in os.environ:
        # Running in Azure App Service
        logger.info("Running in Azure App Service, using default port 8000")
        log("Running in Azure App Service, using default port 8000")
        return 8000  # Azure will redirect requests to this port
    else:
        # Local development
        logger.info("Using default port 8000 for local development")
        return 8000

if __name__ == "__main__":
    try:
        port = get_port()
        
        # Check if running in Azure App Service
        in_azure = 'WEBSITE_SITE_NAME' in os.environ
        
        if in_azure:
            logger.info(f"Running in Azure App Service: {os.environ.get('WEBSITE_SITE_NAME')}")
            logger.info(f"Home directory: {os.environ.get('HOME')}")
            log(f"Running in Azure App Service: {os.environ.get('WEBSITE_SITE_NAME')}")
            log(f"Home directory: {os.environ.get('HOME')}")
            # List all environment variables
            logger.info("Environment variables:")
            log("Environment variables:")
            for key, value in os.environ.items():
                logger.info(f"  {key}: {value}")
                log(f"  {key}: {value}")
        
        # run the server in https mode if the first argument is https
        # Doesn't do https if running locally, for testing.
        if (len(sys.argv) > 1 and sys.argv[1] == "https") and not in_azure:
            logger.info("Starting HTTPS server")
            log("Starting HTTPS server")
            asyncio.run(start_server(
                fulfill_request=fulfill_request,
                use_https=True,
                ssl_cert_file='fullchain.pem',
                ssl_key_file='privkey.pem',
                port=443
            ))
        else:
            # Use the detected port
            logger.info(f"Starting HTTP server on port {port}")
            log(f"Starting HTTP server on port {port}")
            asyncio.run(start_server(port=port, fulfill_request=fulfill_request))
    finally:
        # Make sure to close the log file when the application exits
        close_logs()