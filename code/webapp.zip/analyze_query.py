import mllm
from prompt_runner import PromptRunner
from prompts import find_prompt, fill_prompt
from state import NLWebHandlerState
import time
from azure_logger import log
from prompt_runner import PromptRunner
import utils
# This is used to analyze the query to determine the type of item being sought and
# whether the user wants a list of the canonical item type of the site or whether
# they want details on a particular item.

class AnalyzeQuery(PromptRunner):
  
    ANALYZE_QUERY_PROMPT_NAME = "AnalyzeQueryPrompt"
    ITEM_TYPE_PROMPT_NAME = "DetectItemTypePrompt"
    MULTI_ITEM_TYPE_QUERY_PROMPT_NAME = "DetectMultiItemTypeQueryPrompt"
    DETECT_QUERY_TYPE_PROMPT_NAME = "DetectQueryTypePrompt"

    def __init__(self, handler):
        self.handler = handler
        self.handler.state.set_analyze_query_done()
        
    async def do(self):
        log(f"Running analyze query prompt")
        return
        tasks = [
            asyncio.create_task(self.run_prompt(self.ANALYZE_QUERY_PROMPT_NAME)),
            asyncio.create_task(self.run_prompt(self.ITEM_TYPE_PROMPT_NAME)),
            asyncio.create_task(self.run_prompt(self.MULTI_ITEM_TYPE_QUERY_PROMPT_NAME)),
            asyncio.create_task(self.run_prompt(self.DETECT_QUERY_TYPE_PROMPT_NAME))
        ]
        responses = await asyncio.gather(*tasks)
        if (responses[0]):
            log(f"analyze_query_prompt: {responses[0]}")
        if (responses[1]):
            log(f"item_type_prompt: {responses[1]}")
        if (responses[2]):
            log(f"multi_item_type_query_prompt: {responses[2]}")
        if (responses[3]):
            log(f"detect_query_type_prompt: {responses[3]}")
        self.handler.state.set_analyze_query_done()
        return
    

if __name__ == "__main__":
    class MockHandler:
        def __init__(self, site, query):
            self.item_type = "Recipe"
            self.site = site
            self.query = query
            self.prev_queries = []
            self.state = NLWebHandlerState(self)

    async def test_analyze_query():
        # Get inputs from user
        site = input("Enter site name (e.g. imdb, seriouseats): ")
        query = input("Enter query: ")

        # Create mock handler
        handler = MockHandler(site, query)
        handler.item_type = utils.siteToItemType(site)
        
        # Create and test AnalyzeQuery instance
        analyzer = AnalyzeQuery(handler)
        
        print("\nAnalyzing query...")
        await analyzer.do()
        
       

    # Run the test
    import asyncio
    asyncio.run(test_analyze_query())