import mllm
import retriever
from trim import trim_json
from prompts import find_prompt, fill_prompt
from state import NLWebHandlerState
import json
from azure_logger import log, close_logs  # Import our new logging utility

# this file contains the classes for the different levels of decontextualization. 
# A traditional chatbot, which generates all the output shown to the user
# and hence has all the context.
# In contrast, with NLWeb, the code generates the results shown. In order to keep
# the processing fast (i.e., not blow up the context window for each query) and cheap
# (i.e., keep token count low) we compute a 'decontextualized' statement of the query
# and use that for generating the new round of answers.

class NoOpDecontextualizer:
    def __init__(self, handler):
        self.handler = handler

    async def do(self):
        self.handler.decontextualized_query = self.handler.query
        self.handler.state.set_decontextualization_done()
        self.handler.requires_decontextualization = False
        print("Decontextualization not required")
        return
    
class PrevQueryDecontextualizer:

    DECONTEXTUALIZE_QUERY_PROMPT_NAME = "PrevQueryDecontextualizer"

    def get_prompt(self):
        # if the prompt is not found, return None, None, meaning no decontexualization is to be
        # done for this instance of NLWeb
        item_type = self.handler.item_type
        site = self.handler.site
        prompt_str, ans_struc = find_prompt(site, item_type, self.DECONTEXTUALIZE_QUERY_PROMPT_NAME)
        if prompt_str is None:
            return None, None
        else:
            return prompt_str, ans_struc
      
    def __init__(self, handler):
        self.handler = handler

    async def do(self):
        prompt_str, ans_struc = self.get_prompt()
        if prompt_str is None:
            self.handler.requires_decontextualization = False
            self.handler.state.set_decontextualization_done()
            return
        prompt = fill_prompt(prompt_str, self.handler)
        response = await mllm.get_structured_completion_async(prompt, ans_struc, "gpt-4o")
        if (response["requires_decontextualization"] == "True"):
            self.handler.requires_decontextualization = True
            self.handler.abort_fast_track = True
            self.handler.decontextualized_query = response["decontextualized_query"]
            log(f"Decontextualized query: {self.handler.decontextualized_query}")
        else:
            self.handler.decontextualized_query = self.handler.query
        self.handler.state.set_decontextualization_done()
        log(f"Decontextualized query: {self.handler.decontextualized_query}")
        return

class ContextUrlDecontextualizer(PrevQueryDecontextualizer):
    
    DECONTEXTUALIZE_QUERY_PROMPT_NAME = "DecontextualizeContextPrompt"
     
    def __init__(self, handler):
        self.handler = handler
        self.context_url = handler.context_url
        self.retriever = self.retriever()

    def retriever(self):
        return retriever.DBItemRetriever(self.handler)  

    async def do(self):
        prompt_str, ans_struc = self.get_prompt()
        if prompt_str is None:
            self.handler.requires_decontextualization = False
            self.handler.state.set_decontextualization_done()
            return
        await self.retriever.do()
        item = self.retriever.handler.context_item
        if (item is None):
            self.handler.requires_decontextualization = False
            self.handler.state.set_decontextualization_done()
            return
        else:
            (url, schema_json, name, site) = item
            self.context_description = json.dumps(trim_json(schema_json))
            self.handler.context_description = self.context_description
            prompt = fill_prompt(prompt_str, self.handler)
            response = await mllm.get_structured_completion_async(prompt, ans_struc, "gpt-4o")
            self.handler.requires_decontextualization = True
            self.handler.abort_fast_track = True
            self.handler.decontextualized_query = response["decontextualized_query"]
            self.handler.state.set_decontextualization_done()
            return

class FullDecontextualizer(ContextUrlDecontextualizer):
    
    DECONTEXTUALIZE_QUERY_PROMPT_NAME = "FullDecontextualizePrompt"

    def __init__(self, handler):
       super().__init__(handler)
   